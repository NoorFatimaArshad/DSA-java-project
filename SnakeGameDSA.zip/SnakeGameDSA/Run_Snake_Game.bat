@echo off
setlocal

REM ======================================================
REM  Snake Game DSA - Windows Launcher
REM  This file compiles and runs the Java Swing project.
REM ======================================================

cd /d "%~dp0"

where javac >nul 2>nul
if errorlevel 1 (
    echo.
    echo Java JDK was not found on this computer.
    echo Please install JDK 8 or newer, then run this file again.
    echo.
    pause
    exit /b 1
)

echo Compiling Snake Game DSA...
javac -encoding UTF-8 src\*.java

if errorlevel 1 (
    echo.
    echo Compilation failed. Please check the Java files for errors.
    echo.
    pause
    exit /b 1
)

echo.
echo Starting Snake Game DSA...
echo.
java -cp src Main

echo.
echo Game closed.
pause
