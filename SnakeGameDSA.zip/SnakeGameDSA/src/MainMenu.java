import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * MainMenu handles navigation between all screens with an upgraded modern GUI.
 */
public class MainMenu extends JPanel {
    private final JFrame frame;
    private final ScoreManager scoreManager;
    private final PlayerHistoryManager historyManager;

    public MainMenu(JFrame frame, ScoreManager scoreManager, PlayerHistoryManager historyManager) {
        this.frame = frame;
        this.scoreManager = scoreManager;
        this.historyManager = historyManager;
        buildWelcomeScreen();
    }

    @Override
    protected void paintComponent(Graphics g) {
        UITheme.paintGradientBackground(g, getWidth(), getHeight());
        super.paintComponent(g);
    }

    private void baseLayout() {
        removeAll();
        setOpaque(false);
        setLayout(new BorderLayout());
    }

    private void buildWelcomeScreen() {
        baseLayout();

        JLayeredPane layeredPane = new JLayeredPane() {
            @Override
            public void doLayout() {
                for (Component component : getComponents()) {
                    component.setBounds(0, 0, getWidth(), getHeight());
                }
            }
        };
        AnimatedSnakePanel animatedBackground = new AnimatedSnakePanel();
        animatedBackground.setLayout(new BorderLayout());

        JPanel overlay = new JPanel(new GridBagLayout());
        overlay.setOpaque(false);

        RoundedPanel menuCard = new RoundedPanel(30, new Color(12, 18, 30, 210));
        menuCard.setLayout(new BorderLayout(0, 24));
        menuCard.setBorder(new EmptyBorder(32, 36, 32, 36));
        menuCard.setPreferredSize(new Dimension(460, 540));

        JPanel titlePanel = new JPanel(new GridLayout(3, 1, 0, 8));
        titlePanel.setOpaque(false);
        JLabel title = UITheme.title("Snake Game", 40, UITheme.PRIMARY);
        JLabel subtitle = UITheme.text("Animated background main menu", 16, UITheme.MUTED);
        JLabel mini = UITheme.text("Smooth gameplay • Better visuals • Clean layout", 13, new Color(190, 210, 222));
        titlePanel.add(title);
        titlePanel.add(subtitle);
        titlePanel.add(mini);

        JPanel buttonPanel = new JPanel(new GridLayout(6, 1, 14, 14));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(new EmptyBorder(4, 18, 0, 18));

        JButton startBtn = modernButton("▶ Single Player");
        JButton multiplayerBtn = modernButton("⚔ Two Player Mode");
        JButton highScoreBtn = modernButton("★ High Scores");
        JButton historyBtn = modernButton("☰ Player History");
        JButton instructionBtn = modernButton("? Instructions");
        JButton exitBtn = modernButton("Exit", true);

        startBtn.addActionListener(e -> showPlayerNameScreen());
        multiplayerBtn.addActionListener(e -> showMultiplayerNameScreen());
        highScoreBtn.addActionListener(e -> showHighScoresScreen());
        historyBtn.addActionListener(e -> showHistoryScreen());
        instructionBtn.addActionListener(e -> showInstructionsScreen());
        exitBtn.addActionListener(e -> System.exit(0));

        buttonPanel.add(startBtn);
        buttonPanel.add(multiplayerBtn);
        buttonPanel.add(highScoreBtn);
        buttonPanel.add(historyBtn);
        buttonPanel.add(instructionBtn);
        buttonPanel.add(exitBtn);

        menuCard.add(titlePanel, BorderLayout.NORTH);
        menuCard.add(buttonPanel, BorderLayout.CENTER);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(0, 0, 0, 0);
        overlay.add(menuCard, gbc);

        layeredPane.add(animatedBackground, Integer.valueOf(0));
        layeredPane.add(overlay, Integer.valueOf(1));

        add(layeredPane, BorderLayout.CENTER);

        revalidate();
        repaint();
    }

    private JButton modernButton(String text) {
        return new ModernButton(text);
    }

    private JButton modernButton(String text, boolean danger) {
        return new ModernButton(text, danger);
    }

    private void showPlayerNameScreen() {
        baseLayout();

        JLabel title = UITheme.title("Enter Player Details", 38, UITheme.TEXT);
        title.setBorder(new EmptyBorder(60, 0, 15, 0));

        RoundedPanel card = UITheme.card();
        card.setLayout(new GridLayout(7, 1, 12, 12));
        card.setPreferredSize(new Dimension(420, 430));

        JTextField nameField = new JTextField();
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        nameField.setHorizontalAlignment(JTextField.CENTER);
        nameField.setBackground(new Color(230, 245, 248));
        nameField.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));

        JComboBox<String> difficultyBox = new JComboBox<>(new String[]{"Easy", "Medium", "Hard"});
        difficultyBox.setFont(new Font("Segoe UI", Font.BOLD, 17));
        difficultyBox.setBackground(Color.WHITE);

        JButton start = modernButton("Start Game");
        JButton back = modernButton("Back to Menu");

        start.addActionListener(e -> {
            String playerName = nameField.getText().trim();
            String difficulty = (String) difficultyBox.getSelectedItem();
            if (playerName.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Player name cannot be empty.");
                return;
            }
            startGame(playerName, difficulty);
        });
        back.addActionListener(e -> buildWelcomeScreen());

        card.add(label("Player Name"));
        card.add(nameField);
        card.add(label("Difficulty Level"));
        card.add(difficultyBox);
        card.add(spacerText("Tip: Press H in-game to display A* pathfinding."));
        card.add(start);
        card.add(back);

        JPanel center = new JPanel(new GridBagLayout());
        center.setOpaque(false);
        center.add(card);

        add(title, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        revalidate();
        repaint();
    }

    private void showMultiplayerNameScreen() {
        baseLayout();

        JLabel title = UITheme.title("Two Player Setup", 38, UITheme.TEXT);
        title.setBorder(new EmptyBorder(45, 0, 15, 0));

        RoundedPanel card = UITheme.card();
        card.setLayout(new GridLayout(9, 1, 10, 10));
        card.setPreferredSize(new Dimension(460, 520));

        JTextField playerOneField = inputField("Player 1");
        JTextField playerTwoField = inputField("Player 2");

        JComboBox<String> difficultyBox = new JComboBox<>(new String[]{"Easy", "Medium", "Hard"});
        difficultyBox.setFont(new Font("Segoe UI", Font.BOLD, 17));
        difficultyBox.setBackground(Color.WHITE);

        JButton start = modernButton("Start Two Player Game");
        JButton back = modernButton("Back to Menu");

        start.addActionListener(e -> {
            String p1 = playerOneField.getText().trim();
            String p2 = playerTwoField.getText().trim();
            String difficulty = (String) difficultyBox.getSelectedItem();
            if (p1.isEmpty()) p1 = "Player 1";
            if (p2.isEmpty()) p2 = "Player 2";
            startMultiplayerGame(p1, p2, difficulty);
        });
        back.addActionListener(e -> buildWelcomeScreen());

        card.add(label("Player 1 Name"));
        card.add(playerOneField);
        card.add(label("Player 2 Name"));
        card.add(playerTwoField);
        card.add(label("Difficulty Level"));
        card.add(difficultyBox);
        card.add(spacerText("Controls: Player 1 = Arrow Keys, Player 2 = W A S D"));
        card.add(start);
        card.add(back);

        JPanel center = new JPanel(new GridBagLayout());
        center.setOpaque(false);
        center.add(card);

        add(title, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        revalidate();
        repaint();
    }

    private JTextField inputField(String placeholder) {
        JTextField field = new JTextField(placeholder);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        field.setHorizontalAlignment(JTextField.CENTER);
        field.setBackground(new Color(230, 245, 248));
        field.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        field.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override public void focusGained(java.awt.event.FocusEvent e) {
                if (field.getText().equals(placeholder)) field.setText("");
            }
            @Override public void focusLost(java.awt.event.FocusEvent e) {
                if (field.getText().trim().isEmpty()) field.setText(placeholder);
            }
        });
        return field;
    }

    private JLabel label(String text) {
        JLabel lbl = new JLabel(text, SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl.setForeground(UITheme.TEXT);
        return lbl;
    }

    private JLabel spacerText(String text) {
        JLabel lbl = new JLabel(text, SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lbl.setForeground(UITheme.MUTED);
        return lbl;
    }

    private void startGame(String playerName, String difficulty) {
        GamePanel gamePanel = new GamePanel(frame, playerName, difficulty, scoreManager, historyManager, this);
        frame.getContentPane().removeAll();
        frame.add(gamePanel, "GAME");
        frame.revalidate();
        frame.repaint();
        gamePanel.requestFocusInWindow();
    }

    private void startMultiplayerGame(String playerOne, String playerTwo, String difficulty) {
        MultiplayerGamePanel multiplayerPanel = new MultiplayerGamePanel(frame, playerOne, playerTwo, difficulty, this);
        frame.getContentPane().removeAll();
        frame.add(multiplayerPanel, "MULTIPLAYER_GAME");
        frame.revalidate();
        frame.repaint();
        multiplayerPanel.requestFocusInWindow();
    }

    public void returnToMenu() {
        frame.getContentPane().removeAll();
        frame.add(this, "MENU");
        buildWelcomeScreen();
        frame.revalidate();
        frame.repaint();
    }

    private void showHighScoresScreen() {
        baseLayout();
        addScreenTitle("High Scores");

        JTextArea area = modernTextArea(scoreManager.getSortedScoresText(), new Font("Consolas", Font.BOLD, 18));
        JTextField searchField = new JTextField();
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        searchField.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        JButton searchBtn = modernButton("Search Player");
        JButton back = modernButton("Back");

        searchBtn.addActionListener(e -> {
            String name = searchField.getText().trim();
            if (!name.isEmpty()) JOptionPane.showMessageDialog(this, scoreManager.searchPlayerScore(name));
        });
        back.addActionListener(e -> buildWelcomeScreen());

        JPanel bottom = new JPanel(new GridLayout(1, 3, 12, 12));
        bottom.setOpaque(false);
        bottom.setBorder(new EmptyBorder(14, 70, 28, 70));
        bottom.add(searchField);
        bottom.add(searchBtn);
        bottom.add(back);

        add(wrapInCard(UITheme.modernScroll(area)), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
        revalidate();
        repaint();
    }

    private void showHistoryScreen() {
        baseLayout();
        addScreenTitle("Player History");
        JTextArea area = modernTextArea(historyManager.loadHistoryText(), new Font("Consolas", Font.PLAIN, 15));
        JButton back = modernButton("Back to Menu");
        back.addActionListener(e -> buildWelcomeScreen());
        JPanel bottom = new JPanel(new GridBagLayout());
        bottom.setOpaque(false);
        bottom.setBorder(new EmptyBorder(14, 330, 28, 330));
        bottom.add(back);
        add(wrapInCard(UITheme.modernScroll(area)), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
        revalidate();
        repaint();
    }

    private void showInstructionsScreen() {
        baseLayout();
        addScreenTitle("Instructions & DSA Features");
        JTextArea area = modernTextArea(
                "Single Player Controls:\n\n" +
                "• Arrow Keys: Move snake\n" +
                "• P: Pause / Resume\n" +
                "• R: Restart game\n" +
                "• H: Show / hide A* shortest path hint\n\n" +
                "Two Player Controls:\n\n" +
                "• Player 1: Arrow Keys\n" +
                "• Player 2: W, A, S, D\n" +
                "• P: Pause / Resume\n" +
                "• R: Restart game\n\n" +
                "Rules:\n\n" +
                "• Eat glowing food to increase score.\n" +
                "• Snake grows after eating food.\n" +
                "• Wall hit: that player loses.\n" +
                "• Self hit: that player loses.\n" +
                "• If both crash together, higher score wins. Equal score is a draw.\n" +
                "• Speed increases after every few points.\n\n" +
                "Advanced DSA Usage:\n\n" +
                "• Custom Linked List stores snake body nodes.\n" +
                "• Custom Queue stores direction inputs.\n" +
                "• HashMap stores player high scores.\n" +
                "• File handling stores high scores and player history.\n" +
                "• A* pathfinding uses graph search, Manhattan heuristic, and a custom Min-Heap.\n\n" +
                "GUI Upgrade:\n\n" +
                "• Gradient theme, rounded cards, polished buttons, modern HUD, glowing food, and improved snake rendering.",
                new Font("Segoe UI", Font.PLAIN, 17));
        JButton back = modernButton("Back to Menu");
        back.addActionListener(e -> buildWelcomeScreen());
        JPanel bottom = new JPanel(new GridBagLayout());
        bottom.setOpaque(false);
        bottom.setBorder(new EmptyBorder(14, 330, 28, 330));
        bottom.add(back);
        add(wrapInCard(UITheme.modernScroll(area)), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);
        revalidate();
        repaint();
    }

    private void addScreenTitle(String text) {
        JLabel title = UITheme.title(text, 38, UITheme.PRIMARY);
        title.setBorder(new EmptyBorder(35, 0, 22, 0));
        add(title, BorderLayout.NORTH);
    }

    private JTextArea modernTextArea(String text, Font font) {
        JTextArea area = new JTextArea(text);
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFont(font);
        area.setBackground(new Color(13, 19, 31));
        area.setForeground(UITheme.TEXT);
        area.setCaretColor(UITheme.TEXT);
        area.setMargin(new Insets(22, 24, 22, 24));
        return area;
    }

    private JPanel wrapInCard(Component component) {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setOpaque(false);
        outer.setBorder(new EmptyBorder(0, 70, 0, 70));
        RoundedPanel card = UITheme.card();
        card.setLayout(new BorderLayout());
        card.add(component, BorderLayout.CENTER);
        outer.add(card, BorderLayout.CENTER);
        return outer;
    }
}
