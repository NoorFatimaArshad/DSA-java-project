import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * GameOverPanel displays final score and high score information with modern GUI styling.
 */
public class GameOverPanel extends JPanel {
    public GameOverPanel(JFrame frame, String playerName, int finalScore, int highScore,
                         boolean newHighScore, String difficulty,
                         ScoreManager scoreManager, PlayerHistoryManager historyManager,
                         MainMenu mainMenu) {
        setLayout(new BorderLayout());
        setOpaque(false);

        JLabel title = UITheme.title("Game Over", 52, UITheme.WARNING);
        title.setBorder(new EmptyBorder(65, 0, 20, 0));

        RoundedPanel card = UITheme.card();
        card.setLayout(new GridLayout(5, 1, 8, 8));
        card.setPreferredSize(new Dimension(470, 290));

        card.add(row("Player", playerName));
        card.add(row("Final Score", String.valueOf(finalScore)));
        card.add(row("High Score", String.valueOf(highScore)));
        card.add(row("Difficulty", difficulty));
        JLabel message = UITheme.text(newHighScore ? "New High Score! Excellent work." : "Try again to beat your high score.", 18, newHighScore ? UITheme.PRIMARY : UITheme.MUTED);
        message.setFont(new Font("Segoe UI", Font.BOLD, 18));
        card.add(message);

        JPanel cardWrap = new JPanel(new GridBagLayout());
        cardWrap.setOpaque(false);
        cardWrap.add(card);

        JButton playAgain = new ModernButton("Play Again");
        JButton menu = new ModernButton("Main Menu");

        playAgain.addActionListener(e -> {
            GamePanel gamePanel = new GamePanel(frame, playerName, difficulty, scoreManager, historyManager, mainMenu);
            frame.getContentPane().removeAll();
            frame.add(gamePanel, "GAME");
            frame.revalidate();
            frame.repaint();
            gamePanel.requestFocusInWindow();
        });
        menu.addActionListener(e -> mainMenu.returnToMenu());

        JPanel buttons = new JPanel(new GridLayout(1, 2, 18, 18));
        buttons.setOpaque(false);
        buttons.setBorder(new EmptyBorder(35, 280, 80, 280));
        buttons.add(playAgain);
        buttons.add(menu);

        add(title, BorderLayout.NORTH);
        add(cardWrap, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
    }

    @Override
    protected void paintComponent(Graphics g) {
        UITheme.paintGradientBackground(g, getWidth(), getHeight());
        super.paintComponent(g);
    }

    private JPanel row(String label, String value) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        JLabel l = new JLabel(label);
        l.setFont(new Font("Segoe UI", Font.BOLD, 15));
        l.setForeground(UITheme.MUTED);
        JLabel v = new JLabel(value, SwingConstants.RIGHT);
        v.setFont(new Font("Segoe UI", Font.BOLD, 21));
        v.setForeground(UITheme.TEXT);
        panel.add(l, BorderLayout.WEST);
        panel.add(v, BorderLayout.EAST);
        return panel;
    }
}
