/**
 * Custom Queue for direction inputs.
 * This is manually implemented and does not use Java built-in Queue.
 */
public class DirectionQueue {
    private static class DirectionNode {
        String direction;
        DirectionNode next;

        DirectionNode(String direction) {
            this.direction = direction;
        }
    }

    private DirectionNode front;
    private DirectionNode rear;
    private int size;
    private final int maxSize = 3; // prevents too many buffered inputs

    public DirectionQueue() {
        front = null;
        rear = null;
        size = 0;
    }

    /**
     * Adds a direction to the queue.
     * It checks against the last queued direction, not only current direction,
     * so quick key presses cannot create an invalid reverse move.
     */
    public void enqueue(String direction, String currentDirection) {
        if (size >= maxSize) return;

        String comparisonDirection = (rear == null) ? currentDirection : rear.direction;
        if (isReverse(comparisonDirection, direction)) return;
        if (comparisonDirection.equals(direction)) return;

        DirectionNode newNode = new DirectionNode(direction);
        if (rear == null) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
        size++;
    }

    public String dequeue() {
        if (front == null) return null;

        String direction = front.direction;
        front = front.next;
        if (front == null) rear = null;
        size--;
        return direction;
    }

    public void clear() {
        front = null;
        rear = null;
        size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    private boolean isReverse(String current, String next) {
        return (current.equals("UP") && next.equals("DOWN")) ||
               (current.equals("DOWN") && next.equals("UP")) ||
               (current.equals("LEFT") && next.equals("RIGHT")) ||
               (current.equals("RIGHT") && next.equals("LEFT"));
    }
}
