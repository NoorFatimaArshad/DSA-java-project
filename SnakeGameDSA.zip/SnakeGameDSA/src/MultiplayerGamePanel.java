import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

/**
 * Two Player Snake mode.
 * Player 1 uses Arrow Keys. Player 2 uses W, A, S, D.
 * Both snakes use the custom SnakeLinkedList data structure.
 */
public class MultiplayerGamePanel extends JPanel implements ActionListener {
    private final JFrame frame;
    private final String playerOne;
    private final String playerTwo;
    private final String difficulty;
    private final MainMenu mainMenu;

    private final int tileSize = 25;
    private final int boardCols = 32;
    private final int boardRows = 22;
    private final int boardX = 50;
    private final int boardY = 105;

    private SnakeLinkedList snakeOne;
    private SnakeLinkedList snakeTwo;
    private String directionOne = "RIGHT";
    private String directionTwo = "LEFT";
    private boolean directionOneChangedThisTick = false;
    private boolean directionTwoChangedThisTick = false;
    private int scoreOne = 0;
    private int scoreTwo = 0;
    private int foodX;
    private int foodY;
    private boolean running;
    private boolean paused;
    private String winnerMessage = "";
    private Timer timer;
    private int delay;
    private final Random random = new Random();

    private JButton pauseButton;
    private JButton restartButton;
    private JButton menuButton;

    public MultiplayerGamePanel(JFrame frame, String playerOne, String playerTwo, String difficulty, MainMenu mainMenu) {
        this.frame = frame;
        this.playerOne = playerOne;
        this.playerTwo = playerTwo;
        this.difficulty = difficulty;
        this.mainMenu = mainMenu;
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        setLayout(null);
        setOpaque(false);
        setupButtons();
        setupKeyBindings();
        initializeGame();
        SwingUtilities.invokeLater(this::requestFocusInWindow);
    }

    private void setupButtons() {
        pauseButton = button("Pause");
        restartButton = button("Restart");
        menuButton = button("Main Menu");

        pauseButton.setBounds(525, 35, 105, 40);
        restartButton.setBounds(642, 35, 110, 40);
        menuButton.setBounds(764, 35, 118, 40);

        pauseButton.addActionListener(e -> togglePause());
        restartButton.addActionListener(e -> restartGame());
        menuButton.addActionListener(e -> {
            if (timer != null) timer.stop();
            mainMenu.returnToMenu();
        });

        add(pauseButton);
        add(restartButton);
        add(menuButton);
    }

    private JButton button(String text) {
        JButton btn = new ModernButton(text);
        btn.setFocusable(false);
        return btn;
    }

    @Override
    public void addNotify() {
        super.addNotify();
        SwingUtilities.invokeLater(this::requestFocusInWindow);
    }

    private void setupKeyBindings() {
        bindKey("P1_UP", KeyEvent.VK_UP, () -> changeDirection(1, "UP"));
        bindKey("P1_DOWN", KeyEvent.VK_DOWN, () -> changeDirection(1, "DOWN"));
        bindKey("P1_LEFT", KeyEvent.VK_LEFT, () -> changeDirection(1, "LEFT"));
        bindKey("P1_RIGHT", KeyEvent.VK_RIGHT, () -> changeDirection(1, "RIGHT"));

        bindKey("P2_UP", KeyEvent.VK_W, () -> changeDirection(2, "UP"));
        bindKey("P2_DOWN", KeyEvent.VK_S, () -> changeDirection(2, "DOWN"));
        bindKey("P2_LEFT", KeyEvent.VK_A, () -> changeDirection(2, "LEFT"));
        bindKey("P2_RIGHT", KeyEvent.VK_D, () -> changeDirection(2, "RIGHT"));

        bindKey("PAUSE", KeyEvent.VK_P, this::togglePause);
        bindKey("RESTART", KeyEvent.VK_R, this::restartGame);
    }

    private void bindKey(String name, int keyCode, Runnable action) {
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(keyCode, 0), name);
        getActionMap().put(name, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                action.run();
            }
        });
    }

    private void changeDirection(int player, String next) {
        if (!running || paused) return;

        // Only allow one direction change per timer tick.
        // This prevents fast key presses such as RIGHT -> UP -> LEFT before the snake moves,
        // which can make a very short snake turn back into its own body at the start.
        if (player == 1) {
            if (directionOneChangedThisTick) return;
            if (!isReverse(directionOne, next)) {
                directionOne = next;
                directionOneChangedThisTick = true;
            }
        } else if (player == 2) {
            if (directionTwoChangedThisTick) return;
            if (!isReverse(directionTwo, next)) {
                directionTwo = next;
                directionTwoChangedThisTick = true;
            }
        }
    }

    private boolean isReverse(String current, String next) {
        return (current.equals("UP") && next.equals("DOWN")) ||
               (current.equals("DOWN") && next.equals("UP")) ||
               (current.equals("LEFT") && next.equals("RIGHT")) ||
               (current.equals("RIGHT") && next.equals("LEFT"));
    }

    private void initializeGame() {
        snakeOne = new SnakeLinkedList();
        snakeTwo = new SnakeLinkedList();

        snakeOne.addHead(5, 7);
        snakeOne.addHead(6, 7);
        snakeOne.addHead(7, 7);
        directionOne = "RIGHT";
        directionOneChangedThisTick = false;

        snakeTwo.addHead(26, 15);
        snakeTwo.addHead(25, 15);
        snakeTwo.addHead(24, 15);
        directionTwo = "LEFT";
        directionTwoChangedThisTick = false;

        scoreOne = 0;
        scoreTwo = 0;
        winnerMessage = "";
        running = true;
        paused = false;
        pauseButton.setText("Pause");
        delay = getInitialDelay();
        generateFood();

        if (timer != null) timer.stop();
        timer = new Timer(delay, this);
        timer.start();
    }

    private int getInitialDelay() {
        switch (difficulty) {
            case "Easy": return 175;
            case "Hard": return 90;
            default: return 125;
        }
    }

    private void generateFood() {
        do {
            foodX = random.nextInt(boardCols);
            foodY = random.nextInt(boardRows);
        } while (snakeOne.contains(foodX, foodY) || snakeTwo.contains(foodX, foodY));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (running && !paused) {
            moveSnakes();
            checkCollisions();
        }
        repaint();
    }

    private void moveSnakes() {
        // A new movement step is starting, so both players may turn once again.
        directionOneChangedThisTick = false;
        directionTwoChangedThisTick = false;

        SnakeNode headOne = snakeOne.getHead();
        SnakeNode headTwo = snakeTwo.getHead();

        int oneX = headOne.x;
        int oneY = headOne.y;
        int twoX = headTwo.x;
        int twoY = headTwo.y;

        switch (directionOne) {
            case "UP": oneY--; break;
            case "DOWN": oneY++; break;
            case "LEFT": oneX--; break;
            case "RIGHT": oneX++; break;
        }
        switch (directionTwo) {
            case "UP": twoY--; break;
            case "DOWN": twoY++; break;
            case "LEFT": twoX--; break;
            case "RIGHT": twoX++; break;
        }

        snakeOne.addHead(oneX, oneY);
        snakeTwo.addHead(twoX, twoY);

        boolean oneAte = oneX == foodX && oneY == foodY;
        boolean twoAte = twoX == foodX && twoY == foodY;

        if (oneAte) scoreOne += 10; else snakeOne.removeTail();
        if (twoAte) scoreTwo += 10; else snakeTwo.removeTail();

        if (oneAte || twoAte) {
            generateFood();
            increaseSpeedIfNeeded();
        }
    }

    private void increaseSpeedIfNeeded() {
        // Increase snake speed by 0.005 seconds after every food eaten.
        // Swing Timer delay is in milliseconds, so 0.005 seconds = 5 ms.
        if (delay > 55) {
            delay = Math.max(55, delay - 5);
            timer.setDelay(delay);
        }
    }

    private void checkCollisions() {
        SnakeNode h1 = snakeOne.getHead();
        SnakeNode h2 = snakeTwo.getHead();

        boolean p1WallHit = outsideBoard(h1);
        boolean p2WallHit = outsideBoard(h2);
        // A snake shorter than 4 segments cannot truly hit itself in normal Snake movement.
        // This guard prevents false early-game self-hit results from very rapid input timing.
        boolean p1SelfHit = snakeOne.size() >= 4 && snakeOne.headCollidesWithBody();
        boolean p2SelfHit = snakeTwo.size() >= 4 && snakeTwo.headCollidesWithBody();
        boolean p1OtherSnakeHit = bodyContainsExceptHead(snakeTwo, h1.x, h1.y);
        boolean p2OtherSnakeHit = bodyContainsExceptHead(snakeOne, h2.x, h2.y);

        boolean headToHeadHit = h1.x == h2.x && h1.y == h2.y;

        boolean p1Dead = p1WallHit || p1SelfHit || p1OtherSnakeHit || headToHeadHit;
        boolean p2Dead = p2WallHit || p2SelfHit || p2OtherSnakeHit || headToHeadHit;

        if (p1Dead || p2Dead) {
            running = false;
            timer.stop();

            // Priority rule:
            // 1) A player loses immediately if their snake hits the wall.
            // 2) If no wall hit happens, a player loses if their snake hits its own body.
            // 3) If a snake head hits the other snake body, that player loses.
            // 4) If both snake heads hit each other, higher score wins; equal score is a draw.
            if (p1WallHit || p2WallHit) {
                winnerMessage = getWinnerByWallRule(p1WallHit, p2WallHit);
            } else if (p1SelfHit || p2SelfHit) {
                winnerMessage = getWinnerBySelfRule(p1SelfHit, p2SelfHit);
            } else if (headToHeadHit) {
                winnerMessage = getWinnerByScore();
            } else if (p1OtherSnakeHit || p2OtherSnakeHit) {
                winnerMessage = getWinnerByOtherSnakeBodyRule(p1OtherSnakeHit, p2OtherSnakeHit);
            } else {
                winnerMessage = getWinnerByScore();
            }
        }
    }

    private String getWinnerByWallRule(boolean p1WallHit, boolean p2WallHit) {
        if (p1WallHit && !p2WallHit) {
            return playerTwo + " Wins - " + playerOne + " Hit the Wall!";
        }
        if (p2WallHit && !p1WallHit) {
            return playerOne + " Wins - " + playerTwo + " Hit the Wall!";
        }
        return getWinnerByScore();
    }

    private String getWinnerBySelfRule(boolean p1SelfHit, boolean p2SelfHit) {
        if (p1SelfHit && !p2SelfHit) {
            return playerTwo + " Wins - " + playerOne + " Hit Itself!";
        }
        if (p2SelfHit && !p1SelfHit) {
            return playerOne + " Wins - " + playerTwo + " Hit Itself!";
        }
        return getWinnerByScore();
    }

    private String getWinnerByOtherSnakeBodyRule(boolean p1OtherSnakeHit, boolean p2OtherSnakeHit) {
        if (p1OtherSnakeHit && !p2OtherSnakeHit) {
            return playerTwo + " Wins - " + playerOne + " Hit " + playerTwo + "'s Body!";
        }
        if (p2OtherSnakeHit && !p1OtherSnakeHit) {
            return playerOne + " Wins - " + playerTwo + " Hit " + playerOne + "'s Body!";
        }
        return getWinnerByScore();
    }

    private String getWinnerByScore() {
        if (scoreOne > scoreTwo) {
            return playerOne + " Wins by Higher Score!";
        }
        if (scoreTwo > scoreOne) {
            return playerTwo + " Wins by Higher Score!";
        }
        return "Draw Game - Equal Score";
    }

    private boolean outsideBoard(SnakeNode head) {
        return head.x < 0 || head.x >= boardCols || head.y < 0 || head.y >= boardRows;
    }

    private boolean bodyContainsExceptHead(SnakeLinkedList snake, int x, int y) {
        SnakeNode current = snake.getHead();
        if (current != null) current = current.next;
        while (current != null) {
            if (current.x == x && current.y == y) return true;
            current = current.next;
        }
        return false;
    }

    @Override
    protected void paintComponent(Graphics g) {
        UITheme.paintGradientBackground(g, getWidth(), getHeight());
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        drawTopInfo(g2);
        drawBoard(g2);
        drawFood(g2);
        drawSnake(g2, snakeOne, new Color(63, 238, 137), new Color(15, 150, 86), directionOne);
        drawSnake(g2, snakeTwo, new Color(0, 198, 255), new Color(24, 105, 190), directionTwo);
        drawLegend(g2);
        if (paused) drawOverlay(g2, "PAUSED", "Press P or click Resume to continue");
        if (!running) drawOverlay(g2, winnerMessage, "Press R to restart or Main Menu to exit");
        g2.dispose();
    }

    private void drawTopInfo(Graphics2D g) {
        drawHudCard(g, 45, 28, 170, 50, "PLAYER 1", playerOne + "  " + scoreOne, UITheme.PRIMARY);
        drawHudCard(g, 235, 28, 170, 50, "PLAYER 2", playerTwo + "  " + scoreTwo, UITheme.ACCENT);
        drawHudCard(g, 425, 28, 85, 50, "LEVEL", difficulty, UITheme.TEXT);
    }

    private void drawHudCard(Graphics2D g, int x, int y, int w, int h, String label, String value, Color accent) {
        g.setColor(new Color(0, 0, 0, 75));
        g.fillRoundRect(x + 4, y + 5, w, h, 20, 20);
        g.setPaint(new GradientPaint(x, y, new Color(24, 35, 52, 235), x + w, y + h, new Color(14, 21, 35, 235)));
        g.fillRoundRect(x, y, w, h, 20, 20);
        g.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 160));
        g.drawRoundRect(x, y, w, h, 20, 20);
        g.setFont(new Font("Segoe UI", Font.BOLD, 10));
        g.setColor(UITheme.MUTED);
        g.drawString(label, x + 15, y + 18);
        g.setFont(new Font("Segoe UI", Font.BOLD, 15));
        g.setColor(UITheme.TEXT);
        g.drawString(value, x + 15, y + 40);
    }

    private void drawBoard(Graphics2D g) {
        int w = boardCols * tileSize;
        int h = boardRows * tileSize;
        g.setColor(new Color(0, 0, 0, 110));
        g.fillRoundRect(boardX + 8, boardY + 10, w, h, 28, 28);
        g.setPaint(new GradientPaint(boardX, boardY, new Color(13, 24, 35), boardX + w, boardY + h, new Color(5, 11, 22)));
        g.fillRoundRect(boardX, boardY, w, h, 28, 28);

        for (int y = 0; y < boardRows; y++) {
            for (int x = 0; x < boardCols; x++) {
                if ((x + y) % 2 == 0) {
                    g.setColor(new Color(255, 255, 255, 7));
                    g.fillRect(boardX + x * tileSize, boardY + y * tileSize, tileSize, tileSize);
                }
            }
        }
        g.setStroke(new BasicStroke(3f));
        g.setColor(new Color(63, 238, 137, 150));
        g.drawRoundRect(boardX, boardY, w, h, 28, 28);
        g.setStroke(new BasicStroke(1f));
    }

    private void drawFood(Graphics2D g) {
        int cx = boardX + foodX * tileSize + tileSize / 2;
        int cy = boardY + foodY * tileSize + tileSize / 2;
        g.setColor(new Color(255, 70, 70, 75));
        g.fillOval(cx - 16, cy - 16, 32, 32);
        g.setPaint(new GradientPaint(cx - 8, cy - 8, new Color(255, 190, 90), cx + 8, cy + 8, new Color(255, 35, 70)));
        g.fillOval(cx - 9, cy - 9, 18, 18);
        g.setColor(new Color(255, 255, 255, 180));
        g.fillOval(cx - 4, cy - 5, 5, 5);
    }

    private void drawSnake(Graphics2D g, SnakeLinkedList snake, Color bright, Color dark, String direction) {
        int index = 0;
        for (Point p : snake.toPointList()) {
            int x = boardX + p.x * tileSize;
            int y = boardY + p.y * tileSize;
            if (index == 0) {
                g.setColor(new Color(bright.getRed(), bright.getGreen(), bright.getBlue(), 85));
                g.fillOval(x - 3, y - 3, tileSize + 6, tileSize + 6);
                g.setPaint(new GradientPaint(x, y, bright.brighter(), x + tileSize, y + tileSize, dark));
                g.fillRoundRect(x + 2, y + 2, tileSize - 4, tileSize - 4, 13, 13);
                drawEyes(g, x, y, direction);
            } else {
                g.setPaint(new GradientPaint(x, y, bright.darker(), x + tileSize, y + tileSize, dark.darker()));
                g.fillRoundRect(x + 3, y + 3, tileSize - 6, tileSize - 6, 11, 11);
                g.setColor(new Color(255, 255, 255, 35));
                g.drawRoundRect(x + 3, y + 3, tileSize - 7, tileSize - 7, 11, 11);
            }
            index++;
        }
    }

    private void drawEyes(Graphics2D g, int x, int y, String direction) {
        if (direction.equals("LEFT")) {
            drawEye(g, x + 6, y + 7); drawEye(g, x + 6, y + 15);
        } else if (direction.equals("RIGHT")) {
            drawEye(g, x + 16, y + 7); drawEye(g, x + 16, y + 15);
        } else if (direction.equals("UP")) {
            drawEye(g, x + 7, y + 6); drawEye(g, x + 15, y + 6);
        } else {
            drawEye(g, x + 7, y + 16); drawEye(g, x + 15, y + 16);
        }
    }

    private void drawEye(Graphics2D g, int x, int y) {
        g.setColor(Color.WHITE);
        g.fillOval(x, y, 5, 5);
        g.setColor(new Color(5, 25, 18));
        g.fillOval(x + 2, y + 2, 2, 2);
    }

    private void drawLegend(Graphics2D g) {
        g.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        g.setColor(UITheme.MUTED);
        g.drawString("Player 1: Arrow Keys    Player 2: W A S D    P: Pause    R: Restart", 55, 672);
    }

    private void drawOverlay(Graphics2D g, String title, String sub) {
        g.setColor(new Color(0, 0, 0, 155));
        g.fillRoundRect(boardX, boardY, boardCols * tileSize, boardRows * tileSize, 28, 28);
        g.setFont(new Font("Segoe UI", Font.BOLD, 44));
        g.setColor(UITheme.TEXT);
        FontMetrics fm = g.getFontMetrics();
        g.drawString(title, (getWidth() - fm.stringWidth(title)) / 2, getHeight() / 2 - 10);
        g.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        g.setColor(UITheme.MUTED);
        fm = g.getFontMetrics();
        g.drawString(sub, (getWidth() - fm.stringWidth(sub)) / 2, getHeight() / 2 + 32);
    }

    private void togglePause() {
        if (!running) return;
        paused = !paused;
        pauseButton.setText(paused ? "Resume" : "Pause");
        requestFocusInWindow();
    }

    private void restartGame() {
        initializeGame();
        requestFocusInWindow();
    }
}
