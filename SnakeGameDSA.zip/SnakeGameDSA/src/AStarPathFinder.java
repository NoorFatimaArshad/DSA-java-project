import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Advanced DSA Feature: A* Path Finding
 * ------------------------------------
 * This class treats the game board as a graph where every tile is a vertex.
 * It finds the shortest safe path from the snake head to the food while
 * avoiding walls and the snake body.
 *
 * DSA concepts used:
 * - Graph traversal on a grid
 * - A* search algorithm
 * - Manhattan distance heuristic
 * - Custom Min-Heap priority queue
 * - Parent pointers for path reconstruction
 */
public class AStarPathFinder {
    private final int cols;
    private final int rows;

    public AStarPathFinder(int cols, int rows) {
        this.cols = cols;
        this.rows = rows;
    }

    public ArrayList<Point> findPath(Point start, Point goal, SnakeLinkedList snake) {
        boolean[][] blocked = buildBlockedGrid(snake, start, goal);
        boolean[][] closed = new boolean[cols][rows];
        PathNode[][] nodes = new PathNode[cols][rows];
        MinHeap openSet = new MinHeap(cols * rows);

        PathNode startNode = new PathNode(start.x, start.y);
        startNode.gCost = 0;
        startNode.hCost = heuristic(start.x, start.y, goal.x, goal.y);
        nodes[start.x][start.y] = startNode;
        openSet.insert(startNode);

        int[] dx = {0, 0, -1, 1};
        int[] dy = {-1, 1, 0, 0};

        while (!openSet.isEmpty()) {
            PathNode current = openSet.extractMin();

            if (closed[current.x][current.y]) {
                continue;
            }
            closed[current.x][current.y] = true;

            if (current.x == goal.x && current.y == goal.y) {
                return reconstructPath(current);
            }

            for (int i = 0; i < 4; i++) {
                int nx = current.x + dx[i];
                int ny = current.y + dy[i];

                if (!isInsideBoard(nx, ny) || blocked[nx][ny] || closed[nx][ny]) {
                    continue;
                }

                int newGCost = current.gCost + 1;
                PathNode neighbor = nodes[nx][ny];

                if (neighbor == null) {
                    neighbor = new PathNode(nx, ny);
                    nodes[nx][ny] = neighbor;
                }

                if (newGCost < neighbor.gCost) {
                    neighbor.gCost = newGCost;
                    neighbor.hCost = heuristic(nx, ny, goal.x, goal.y);
                    neighbor.parent = current;
                    openSet.insert(neighbor);
                }
            }
        }

        return new ArrayList<>();
    }

    private boolean[][] buildBlockedGrid(SnakeLinkedList snake, Point start, Point goal) {
        boolean[][] blocked = new boolean[cols][rows];

        for (Point p : snake.toPointList()) {
            if (isInsideBoard(p.x, p.y)) {
                blocked[p.x][p.y] = true;
            }
        }

        // Start and goal must remain available for the algorithm.
        blocked[start.x][start.y] = false;
        blocked[goal.x][goal.y] = false;
        return blocked;
    }

    private int heuristic(int x1, int y1, int x2, int y2) {
        return Math.abs(x1 - x2) + Math.abs(y1 - y2);
    }

    private boolean isInsideBoard(int x, int y) {
        return x >= 0 && x < cols && y >= 0 && y < rows;
    }

    private ArrayList<Point> reconstructPath(PathNode endNode) {
        ArrayList<Point> path = new ArrayList<>();
        PathNode current = endNode;

        while (current != null) {
            path.add(new Point(current.x, current.y));
            current = current.parent;
        }

        Collections.reverse(path);
        return path;
    }

    private static class PathNode {
        int x;
        int y;
        int gCost = Integer.MAX_VALUE;
        int hCost = 0;
        PathNode parent;

        PathNode(int x, int y) {
            this.x = x;
            this.y = y;
        }

        int fCost() {
            return gCost + hCost;
        }
    }

    /** Custom Min-Heap, used instead of Java PriorityQueue. */
    private static class MinHeap {
        private PathNode[] heap;
        private int size;

        MinHeap(int capacity) {
            heap = new PathNode[Math.max(4, capacity)];
            size = 0;
        }

        boolean isEmpty() {
            return size == 0;
        }

        void insert(PathNode node) {
            if (size == heap.length) {
                grow();
            }
            heap[size] = node;
            heapifyUp(size);
            size++;
        }

        PathNode extractMin() {
            if (isEmpty()) {
                return null;
            }

            PathNode min = heap[0];
            size--;
            heap[0] = heap[size];
            heap[size] = null;
            heapifyDown(0);
            return min;
        }

        private void heapifyUp(int index) {
            while (index > 0) {
                int parentIndex = (index - 1) / 2;
                if (compare(heap[index], heap[parentIndex]) >= 0) {
                    break;
                }
                swap(index, parentIndex);
                index = parentIndex;
            }
        }

        private void heapifyDown(int index) {
            while (true) {
                int left = index * 2 + 1;
                int right = index * 2 + 2;
                int smallest = index;

                if (left < size && compare(heap[left], heap[smallest]) < 0) {
                    smallest = left;
                }
                if (right < size && compare(heap[right], heap[smallest]) < 0) {
                    smallest = right;
                }
                if (smallest == index) {
                    break;
                }

                swap(index, smallest);
                index = smallest;
            }
        }

        private int compare(PathNode a, PathNode b) {
            if (a.fCost() != b.fCost()) {
                return a.fCost() - b.fCost();
            }
            return a.hCost - b.hCost;
        }

        private void swap(int i, int j) {
            PathNode temp = heap[i];
            heap[i] = heap[j];
            heap[j] = temp;
        }

        private void grow() {
            PathNode[] larger = new PathNode[heap.length * 2];
            System.arraycopy(heap, 0, larger, 0, heap.length);
            heap = larger;
        }
    }
}
