import java.io.*;
import java.util.*;

/**
 * ScoreManager uses HashMap to store player high scores.
 * It also handles scores.txt file loading and saving.
 */
public class ScoreManager {
    private final HashMap<String, Integer> scores;
    private final File scoreFile;

    public ScoreManager(String fileName) {
        scores = new HashMap<>();
        scoreFile = new File(fileName);
        ensureFileExists();
        loadScores();
    }

    private void ensureFileExists() {
        try {
            if (!scoreFile.exists()) {
                scoreFile.createNewFile();
            }
        } catch (IOException e) {
            System.out.println("Error creating scores file: " + e.getMessage());
        }
    }

    public void loadScores() {
        scores.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(scoreFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split(",");
                if (parts.length != 2) continue;

                String playerName = parts[0].trim();
                try {
                    int score = Integer.parseInt(parts[1].trim());
                    if (!playerName.isEmpty()) {
                        scores.put(playerName, score);
                    }
                } catch (NumberFormatException ignored) {
                    // Invalid score line is skipped to prevent crashes.
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading scores: " + e.getMessage());
        }
    }

    public void saveScores() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(scoreFile))) {
            for (Map.Entry<String, Integer> entry : scores.entrySet()) {
                writer.println(entry.getKey() + "," + entry.getValue());
            }
        } catch (IOException e) {
            System.out.println("Error saving scores: " + e.getMessage());
        }
    }

    /** Update score only when the new score is higher. */
    public boolean updateHighScore(String playerName, int newScore) {
        int oldScore = scores.getOrDefault(playerName, 0);
        if (newScore > oldScore) {
            scores.put(playerName, newScore);
            saveScores();
            return true;
        }
        return false;
    }

    public int getHighScore(String playerName) {
        return scores.getOrDefault(playerName, 0);
    }

    public HashMap<String, Integer> getScores() {
        loadScores();
        return scores;
    }

    public String searchPlayerScore(String playerName) {
        loadScores();
        if (scores.containsKey(playerName)) {
            return playerName + " high score: " + scores.get(playerName);
        }
        return "No score found for: " + playerName;
    }

    public String getSortedScoresText() {
        loadScores();
        if (scores.isEmpty()) return "No records found.";

        ArrayList<Map.Entry<String, Integer>> list = new ArrayList<>(scores.entrySet());
        list.sort((a, b) -> b.getValue() - a.getValue());

        StringBuilder sb = new StringBuilder();
        int rank = 1;
        for (Map.Entry<String, Integer> entry : list) {
            sb.append(rank++)
              .append(". ")
              .append(entry.getKey())
              .append(" - ")
              .append(entry.getValue())
              .append("\n");
        }
        return sb.toString();
    }
}
