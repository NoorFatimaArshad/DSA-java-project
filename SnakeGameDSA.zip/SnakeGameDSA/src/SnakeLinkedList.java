import java.awt.Point;
import java.util.ArrayList;

/**
 * Custom Linked List for snake body.
 * Built manually instead of using Java built-in LinkedList.
 * Head represents the front of the snake.
 */
public class SnakeLinkedList {
    private SnakeNode head;
    private SnakeNode tail;
    private int size;

    public SnakeLinkedList() {
        head = null;
        tail = null;
        size = 0;
    }

    /** Add a new head segment. */
    public void addHead(int x, int y) {
        SnakeNode newNode = new SnakeNode(x, y);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            newNode.next = head;
            head = newNode;
        }
        size++;
    }

    /** Remove the last segment unless food is eaten. */
    public void removeTail() {
        if (head == null) return;

        if (head == tail) {
            head = null;
            tail = null;
            size = 0;
            return;
        }

        SnakeNode current = head;
        while (current.next != tail) {
            current = current.next;
        }
        current.next = null;
        tail = current;
        size--;
    }

    public SnakeNode getHead() {
        return head;
    }

    public int size() {
        return size;
    }

    /** Check whether any segment is present at x,y. */
    public boolean contains(int x, int y) {
        SnakeNode current = head;
        while (current != null) {
            if (current.x == x && current.y == y) return true;
            current = current.next;
        }
        return false;
    }

    /** Check if head collides with its own body. */
    public boolean headCollidesWithBody() {
        if (head == null) return false;
        SnakeNode current = head.next;
        while (current != null) {
            if (head.x == current.x && head.y == current.y) return true;
            current = current.next;
        }
        return false;
    }

    /** Return all body points for drawing. */
    public ArrayList<Point> toPointList() {
        ArrayList<Point> points = new ArrayList<>();
        SnakeNode current = head;
        while (current != null) {
            points.add(new Point(current.x, current.y));
            current = current.next;
        }
        return points;
    }
}
