import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import java.util.ArrayList;

/**
 * GamePanel handles actual game drawing, animation, movement,
 * collision detection, food generation, pause/resume, and restart.
 * GUI upgraded with gradient background, rounded HUD cards, glowing food,
 * modern snake segments, and a clearer A* path hint visualization.
 */
public class GamePanel extends JPanel implements ActionListener {
    private final JFrame frame;
    private final String playerName;
    private final String difficulty;
    private final ScoreManager scoreManager;
    private final PlayerHistoryManager historyManager;
    private final MainMenu mainMenu;

    private final int tileSize = 25;
    private final int boardCols = 32;
    private final int boardRows = 22;
    private final int boardX = 50;
    private final int boardY = 105;

    private SnakeLinkedList snake;
    private DirectionQueue directionQueue;
    private AStarPathFinder pathFinder;
    private ArrayList<Point> currentPath;
    private boolean showPathHint;
    private String currentDirection = "RIGHT";
    private int foodX;
    private int foodY;
    private int score;
    private boolean running;
    private boolean paused;
    private Timer timer;
    private int delay;
    private final Random random = new Random();

    private JButton pauseButton;
    private JButton restartButton;
    private JButton menuButton;

    public GamePanel(JFrame frame, String playerName, String difficulty,
                     ScoreManager scoreManager, PlayerHistoryManager historyManager,
                     MainMenu mainMenu) {
        this.frame = frame;
        this.playerName = playerName;
        this.difficulty = difficulty;
        this.scoreManager = scoreManager;
        this.historyManager = historyManager;
        this.mainMenu = mainMenu;

        setFocusable(true);
        setLayout(null);
        setOpaque(false);
        setupButtons();
        setupKeyBindings();
        initializeGame();
    }

    private void setupButtons() {
        pauseButton = button("Pause");
        restartButton = button("Restart");
        menuButton = button("Main Menu");

        pauseButton.setBounds(525, 35, 105, 40);
        restartButton.setBounds(642, 35, 110, 40);
        menuButton.setBounds(764, 35, 118, 40);

        pauseButton.addActionListener(e -> togglePause());
        restartButton.addActionListener(e -> restartGame());
        menuButton.addActionListener(e -> {
            if (timer != null) timer.stop();
            mainMenu.returnToMenu();
        });

        add(pauseButton);
        add(restartButton);
        add(menuButton);
    }

    private JButton button(String text) {
        JButton btn = new ModernButton(text);
        btn.setFocusable(false);
        return btn;
    }

    /**
     * Swing key bindings are more reliable than KeyListener for games,
     * especially after clicking buttons because buttons can take keyboard focus.
     */
    private void setupKeyBindings() {
        bindKey("UP", KeyEvent.VK_UP, () -> addDirection("UP"));
        bindKey("DOWN", KeyEvent.VK_DOWN, () -> addDirection("DOWN"));
        bindKey("LEFT", KeyEvent.VK_LEFT, () -> addDirection("LEFT"));
        bindKey("RIGHT", KeyEvent.VK_RIGHT, () -> addDirection("RIGHT"));
        bindKey("P", KeyEvent.VK_P, this::togglePause);
        bindKey("R", KeyEvent.VK_R, this::restartGame);
        bindKey("H", KeyEvent.VK_H, this::togglePathHint);
    }

    private void bindKey(String name, int keyCode, Runnable action) {
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(keyCode, 0), name);
        getActionMap().put(name, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                action.run();
            }
        });
    }

    private void addDirection(String direction) {
        directionQueue.enqueue(direction, currentDirection);
    }

    private void initializeGame() {
        snake = new SnakeLinkedList();
        directionQueue = new DirectionQueue();
        pathFinder = new AStarPathFinder(boardCols, boardRows);
        currentPath = new ArrayList<>();
        showPathHint = false;
        currentDirection = "RIGHT";
        score = 0;
        running = true;
        paused = false;

        snake.addHead(5, 10);
        snake.addHead(6, 10);
        snake.addHead(7, 10);

        delay = getInitialDelay();
        generateFood();

        if (timer != null) timer.stop();
        timer = new Timer(delay, this);
        timer.start();
    }

    private int getInitialDelay() {
        switch (difficulty) {
            case "Easy": return 170;
            case "Hard": return 80;
            default: return 120;
        }
    }

    private void generateFood() {
        do {
            foodX = random.nextInt(boardCols);
            foodY = random.nextInt(boardRows);
        } while (snake.contains(foodX, foodY));
    }

    @Override
    protected void paintComponent(Graphics g) {
        UITheme.paintGradientBackground(g, getWidth(), getHeight());
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        drawTopInfo(g2);
        drawBoard(g2);
        drawPathHint(g2);
        drawFood(g2);
        drawSnake(g2);
        drawLegend(g2);

        if (paused) {
            drawPauseOverlay(g2);
        }
        g2.dispose();
    }

    private void drawTopInfo(Graphics2D g) {
        drawHudCard(g, 45, 28, 145, 50, "PLAYER", playerName);
        drawHudCard(g, 205, 28, 105, 50, "SCORE", String.valueOf(score));
        drawHudCard(g, 325, 28, 155, 50, "LEVEL", difficulty);
    }

    private void drawHudCard(Graphics2D g, int x, int y, int w, int h, String label, String value) {
        g.setColor(new Color(0, 0, 0, 75));
        g.fillRoundRect(x + 4, y + 5, w, h, 20, 20);
        g.setPaint(new GradientPaint(x, y, new Color(24, 35, 52, 235), x + w, y + h, new Color(14, 21, 35, 235)));
        g.fillRoundRect(x, y, w, h, 20, 20);
        g.setColor(new Color(255, 255, 255, 35));
        g.drawRoundRect(x, y, w, h, 20, 20);
        g.setFont(new Font("Segoe UI", Font.BOLD, 10));
        g.setColor(UITheme.MUTED);
        g.drawString(label, x + 15, y + 18);
        g.setFont(new Font("Segoe UI", Font.BOLD, 18));
        g.setColor(UITheme.TEXT);
        g.drawString(value, x + 15, y + 40);
    }

    private void drawBoard(Graphics2D g) {
        int w = boardCols * tileSize;
        int h = boardRows * tileSize;

        g.setColor(new Color(0, 0, 0, 110));
        g.fillRoundRect(boardX + 8, boardY + 10, w, h, 28, 28);

        g.setPaint(new GradientPaint(boardX, boardY, new Color(13, 24, 35), boardX + w, boardY + h, new Color(5, 11, 22)));
        g.fillRoundRect(boardX, boardY, w, h, 28, 28);

        // Subtle checker/grid texture.
        for (int y = 0; y < boardRows; y++) {
            for (int x = 0; x < boardCols; x++) {
                if ((x + y) % 2 == 0) {
                    g.setColor(new Color(255, 255, 255, 7));
                    g.fillRect(boardX + x * tileSize, boardY + y * tileSize, tileSize, tileSize);
                }
            }
        }

        g.setColor(new Color(255, 255, 255, 18));
        for (int i = 1; i < boardCols; i++) {
            g.drawLine(boardX + i * tileSize, boardY, boardX + i * tileSize, boardY + h);
        }
        for (int i = 1; i < boardRows; i++) {
            g.drawLine(boardX, boardY + i * tileSize, boardX + w, boardY + i * tileSize);
        }

        g.setStroke(new BasicStroke(3f));
        g.setColor(new Color(63, 238, 137, 190));
        g.drawRoundRect(boardX, boardY, w, h, 28, 28);
        g.setStroke(new BasicStroke(1f));
        g.setColor(new Color(0, 198, 255, 95));
        g.drawRoundRect(boardX + 5, boardY + 5, w - 10, h - 10, 22, 22);
    }

    private void drawFood(Graphics2D g) {
        int cx = boardX + foodX * tileSize + tileSize / 2;
        int cy = boardY + foodY * tileSize + tileSize / 2;
        g.setColor(new Color(255, 70, 70, 60));
        g.fillOval(cx - 16, cy - 16, 32, 32);
        g.setColor(new Color(255, 70, 70, 120));
        g.fillOval(cx - 12, cy - 12, 24, 24);
        g.setPaint(new GradientPaint(cx - 8, cy - 8, new Color(255, 170, 110), cx + 8, cy + 8, new Color(255, 35, 70)));
        g.fillOval(cx - 9, cy - 9, 18, 18);
        g.setColor(new Color(255, 255, 255, 180));
        g.fillOval(cx - 4, cy - 5, 5, 5);
    }

    private void drawPathHint(Graphics2D g) {
        if (!showPathHint || currentPath == null || currentPath.isEmpty()) return;

        g.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(new Color(255, 218, 80, 160));
        for (int i = 1; i < currentPath.size(); i++) {
            Point prev = currentPath.get(i - 1);
            Point p = currentPath.get(i);
            int x1 = boardX + prev.x * tileSize + tileSize / 2;
            int y1 = boardY + prev.y * tileSize + tileSize / 2;
            int x2 = boardX + p.x * tileSize + tileSize / 2;
            int y2 = boardY + p.y * tileSize + tileSize / 2;
            g.drawLine(x1, y1, x2, y2);
            g.fillOval(x2 - 4, y2 - 4, 8, 8);
        }
        g.setStroke(new BasicStroke(1f));
    }

    private void drawSnake(Graphics2D g) {
        int index = 0;
        for (Point p : snake.toPointList()) {
            int x = boardX + p.x * tileSize;
            int y = boardY + p.y * tileSize;
            if (index == 0) {
                g.setColor(new Color(63, 238, 137, 75));
                g.fillOval(x - 3, y - 3, tileSize + 6, tileSize + 6);
                g.setPaint(new GradientPaint(x, y, new Color(140, 255, 170), x + tileSize, y + tileSize, new Color(28, 183, 98)));
                g.fillRoundRect(x + 2, y + 2, tileSize - 4, tileSize - 4, 13, 13);
                g.setColor(new Color(5, 40, 25));
                drawEyes(g, x, y);
            } else {
                float fade = Math.max(0.45f, 1f - (index * 0.025f));
                int green = (int) (190 * fade);
                g.setPaint(new GradientPaint(x, y, new Color(45, Math.max(green, 95), 90), x + tileSize, y + tileSize, new Color(16, 105, 72)));
                g.fillRoundRect(x + 3, y + 3, tileSize - 6, tileSize - 6, 11, 11);
                g.setColor(new Color(255, 255, 255, 40));
                g.drawRoundRect(x + 3, y + 3, tileSize - 7, tileSize - 7, 11, 11);
            }
            index++;
        }
    }

    private void drawEyes(Graphics2D g, int x, int y) {
        int leftX = x + 7;
        int rightX = x + 15;
        int eyeY = y + 8;
        if (currentDirection.equals("LEFT")) {
            leftX = x + 6; rightX = x + 6; eyeY = y + 7;
            drawEye(g, leftX, eyeY); drawEye(g, rightX, y + 15);
        } else if (currentDirection.equals("RIGHT")) {
            leftX = x + 16; rightX = x + 16; eyeY = y + 7;
            drawEye(g, leftX, eyeY); drawEye(g, rightX, y + 15);
        } else if (currentDirection.equals("UP")) {
            drawEye(g, x + 7, y + 6); drawEye(g, x + 15, y + 6);
        } else {
            drawEye(g, x + 7, y + 16); drawEye(g, x + 15, y + 16);
        }
    }

    private void drawEye(Graphics2D g, int x, int y) {
        g.setColor(Color.WHITE);
        g.fillOval(x, y, 5, 5);
        g.setColor(new Color(5, 25, 18));
        g.fillOval(x + 2, y + 2, 2, 2);
    }

    private void drawLegend(Graphics2D g) {
        int y = 672;
        g.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        g.setColor(UITheme.MUTED);
        String hintStatus = showPathHint ? "ON" : "OFF";
        g.drawString("Arrow Keys: Move    P: Pause    R: Restart    H: A* Path Hint " + hintStatus, 55, y);
    }

    private void drawPauseOverlay(Graphics2D g) {
        g.setColor(new Color(0, 0, 0, 145));
        g.fillRoundRect(boardX, boardY, boardCols * tileSize, boardRows * tileSize, 28, 28);
        drawCenteredText(g, "PAUSED", 46, UITheme.TEXT);
        g.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        g.setColor(UITheme.MUTED);
        FontMetrics fm = g.getFontMetrics();
        String sub = "Press P or click Resume to continue";
        g.drawString(sub, (getWidth() - fm.stringWidth(sub)) / 2, getHeight() / 2 + 35);
    }

    private void drawCenteredText(Graphics2D g, String text, int size, Color color) {
        g.setFont(new Font("Segoe UI", Font.BOLD, size));
        g.setColor(color);
        FontMetrics fm = g.getFontMetrics();
        int x = (getWidth() - fm.stringWidth(text)) / 2;
        int y = getHeight() / 2;
        g.drawString(text, x, y);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (running && !paused) {
            processDirectionQueue();
            moveSnake();
            checkCollisions();
            if (running) updatePathHint();
        }
        repaint();
    }

    private void processDirectionQueue() {
        String nextDirection = directionQueue.dequeue();
        if (nextDirection != null && !isReverse(currentDirection, nextDirection)) {
            currentDirection = nextDirection;
        }
    }

    private boolean isReverse(String current, String next) {
        return (current.equals("UP") && next.equals("DOWN")) ||
               (current.equals("DOWN") && next.equals("UP")) ||
               (current.equals("LEFT") && next.equals("RIGHT")) ||
               (current.equals("RIGHT") && next.equals("LEFT"));
    }

    private void moveSnake() {
        SnakeNode head = snake.getHead();
        int newX = head.x;
        int newY = head.y;

        switch (currentDirection) {
            case "UP": newY--; break;
            case "DOWN": newY++; break;
            case "LEFT": newX--; break;
            case "RIGHT": newX++; break;
        }

        snake.addHead(newX, newY);

        if (newX == foodX && newY == foodY) {
            score += 10;
            generateFood();
            increaseSpeedIfNeeded();
            playEatSoundPlaceholder();
        } else {
            snake.removeTail();
        }
    }

    private void increaseSpeedIfNeeded() {
        // Increase snake speed by 0.005 seconds after every food eaten.
        // Swing Timer delay is in milliseconds, so 0.005 seconds = 5 ms.
        if (delay > 45) {
            delay = Math.max(45, delay - 5);
            timer.setDelay(delay);
        }
    }

    private void checkCollisions() {
        SnakeNode head = snake.getHead();
        if (head.x < 0 || head.x >= boardCols || head.y < 0 || head.y >= boardRows) {
            endGame("Hit Wall");
            return;
        }
        if (snake.headCollidesWithBody()) endGame("Hit Own Body");
    }

    private void endGame(String result) {
        running = false;
        timer.stop();

        boolean newHighScore = scoreManager.updateHighScore(playerName, score);
        historyManager.saveHistory(playerName, score, result);
        int highScore = scoreManager.getHighScore(playerName);

        GameOverPanel gameOverPanel = new GameOverPanel(frame, playerName, score, highScore,
                newHighScore, difficulty, scoreManager, historyManager, mainMenu);

        frame.getContentPane().removeAll();
        frame.add(gameOverPanel, "GAME_OVER");
        frame.revalidate();
        frame.repaint();
        gameOverPanel.requestFocusInWindow();
    }

    private void togglePathHint() {
        showPathHint = !showPathHint;
        updatePathHint();
        requestFocusInWindow();
    }

    private void updatePathHint() {
        if (!showPathHint || snake == null || snake.getHead() == null || pathFinder == null) return;
        SnakeNode head = snake.getHead();
        if (head.x < 0 || head.x >= boardCols || head.y < 0 || head.y >= boardRows) {
            currentPath.clear();
            return;
        }
        currentPath = pathFinder.findPath(new Point(head.x, head.y), new Point(foodX, foodY), snake);
    }

    private void togglePause() {
        paused = !paused;
        pauseButton.setText(paused ? "Resume" : "Pause");
        requestFocusInWindow();
    }

    private void restartGame() {
        initializeGame();
        pauseButton.setText("Pause");
        requestFocusInWindow();
    }

    private void playEatSoundPlaceholder() {
        // Optional sound placeholder.
        // Toolkit.getDefaultToolkit().beep();
    }
}
