import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Handles player history file operations.
 * Saves player name, score, date/time, and game result.
 */
public class PlayerHistoryManager {
    private final File historyFile;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a");

    public PlayerHistoryManager(String fileName) {
        historyFile = new File(fileName);
        ensureFileExists();
    }

    private void ensureFileExists() {
        try {
            if (!historyFile.exists()) {
                historyFile.createNewFile();
            }
        } catch (IOException e) {
            System.out.println("Error creating history file: " + e.getMessage());
        }
    }

    public void saveHistory(String playerName, int score, String result) {
        String dateTime = LocalDateTime.now().format(formatter);
        try (PrintWriter writer = new PrintWriter(new FileWriter(historyFile, true))) {
            writer.println(playerName + "," + score + "," + dateTime + "," + result);
        } catch (IOException e) {
            System.out.println("Error saving history: " + e.getMessage());
        }
    }

    public String loadHistoryText() {
        StringBuilder sb = new StringBuilder();
        int games = 0;
        int highest = 0;
        String lastPlayed = "N/A";

        try (BufferedReader reader = new BufferedReader(new FileReader(historyFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split(",");
                if (parts.length < 4) continue;

                String player = parts[0].trim();
                int score;
                try {
                    score = Integer.parseInt(parts[1].trim());
                } catch (NumberFormatException e) {
                    continue;
                }
                String dateTime = parts[2].trim();
                String result = parts[3].trim();

                games++;
                highest = Math.max(highest, score);
                lastPlayed = dateTime;

                sb.append("Player: ").append(player)
                  .append(" | Score: ").append(score)
                  .append(" | Date/Time: ").append(dateTime)
                  .append(" | Result: ").append(result)
                  .append("\n");
            }
        } catch (IOException e) {
            return "Error loading history: " + e.getMessage();
        }

        if (games == 0) return "No records found.";

        return "Total Games Played: " + games + "\n" +
               "Highest Score Achieved: " + highest + "\n" +
               "Last Played: " + lastPlayed + "\n\n" +
               sb;
    }
}
