import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Shared modern UI helpers for the Snake DSA project.
 * Keeps the GUI polished without external libraries.
 */
public class UITheme {
    public static final Color BG_TOP = new Color(7, 11, 24);
    public static final Color BG_BOTTOM = new Color(16, 32, 43);
    public static final Color PANEL = new Color(20, 28, 43, 225);
    public static final Color PANEL_DARK = new Color(13, 19, 31, 235);
    public static final Color PRIMARY = new Color(63, 238, 137);
    public static final Color PRIMARY_DARK = new Color(21, 142, 83);
    public static final Color ACCENT = new Color(0, 198, 255);
    public static final Color WARNING = new Color(255, 88, 88);
    public static final Color TEXT = new Color(238, 248, 255);
    public static final Color MUTED = new Color(157, 176, 190);
    public static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 44);
    public static final Font SUBTITLE_FONT = new Font("Segoe UI", Font.PLAIN, 18);
    public static final Font BODY_FONT = new Font("Segoe UI", Font.PLAIN, 15);
    public static final Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 16);

    public static void paintGradientBackground(Graphics g, int width, int height) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        GradientPaint bg = new GradientPaint(0, 0, BG_TOP, width, height, BG_BOTTOM);
        g2.setPaint(bg);
        g2.fillRect(0, 0, width, height);

        g2.setColor(new Color(63, 238, 137, 26));
        g2.fillOval(-110, -90, 300, 300);
        g2.setColor(new Color(0, 198, 255, 22));
        g2.fillOval(width - 220, height - 240, 360, 360);
        g2.setColor(new Color(255, 255, 255, 8));
        for (int i = 0; i < width; i += 60) {
            g2.drawLine(i, 0, i - 220, height);
        }
        g2.dispose();
    }

    public static RoundedPanel card() {
        RoundedPanel panel = new RoundedPanel(26, PANEL);
        panel.setBorder(new EmptyBorder(24, 28, 24, 28));
        panel.setOpaque(false);
        return panel;
    }

    public static JLabel title(String text, int size, Color color) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.BOLD, size));
        label.setForeground(color);
        return label;
    }

    public static JLabel text(String text, int size, Color color) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.PLAIN, size));
        label.setForeground(color);
        return label;
    }

    public static JScrollPane modernScroll(JTextArea area) {
        JScrollPane scroll = new JScrollPane(area);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setOpaque(false);
        scroll.setOpaque(false);
        return scroll;
    }
}

class GradientPanel extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        UITheme.paintGradientBackground(g, getWidth(), getHeight());
        super.paintComponent(g);
    }
}

class RoundedPanel extends JPanel {
    private final int radius;
    private final Color color;

    public RoundedPanel(int radius, Color color) {
        this.radius = radius;
        this.color = color;
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(new Color(0, 0, 0, 70));
        g2.fillRoundRect(5, 7, getWidth() - 10, getHeight() - 10, radius, radius);
        g2.setColor(color);
        g2.fillRoundRect(0, 0, getWidth() - 10, getHeight() - 10, radius, radius);
        g2.setColor(new Color(255, 255, 255, 28));
        g2.drawRoundRect(0, 0, getWidth() - 11, getHeight() - 11, radius, radius);
        g2.dispose();
        super.paintComponent(g);
    }
}

class ModernButton extends JButton {
    private boolean hover;
    private boolean pressed;
    private final boolean danger;
    private float hoverProgress = 0f;
    private float pressProgress = 0f;
    private final javax.swing.Timer animationTimer;

    public ModernButton(String text) {
        this(text, false);
    }

    public ModernButton(String text, boolean danger) {
        super(text);
        this.danger = danger;
        setFont(UITheme.BUTTON_FONT);
        setForeground(Color.WHITE);
        setFocusPainted(false);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setOpaque(false);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setBorder(new EmptyBorder(12, 22, 12, 22));
        setHorizontalAlignment(SwingConstants.CENTER);
        setPreferredSize(new Dimension(300, 54));

        animationTimer = new javax.swing.Timer(15, e -> {
            float hoverTarget = hover ? 1f : 0f;
            float pressTarget = pressed ? 1f : 0f;
            hoverProgress += (hoverTarget - hoverProgress) * 0.22f;
            pressProgress += (pressTarget - pressProgress) * 0.30f;
            if (Math.abs(hoverTarget - hoverProgress) < 0.01f) hoverProgress = hoverTarget;
            if (Math.abs(pressTarget - pressProgress) < 0.01f) pressProgress = pressTarget;
            repaint();
            if (!hover && !pressed && hoverProgress == 0f && pressProgress == 0f) {
                ((javax.swing.Timer) e.getSource()).stop();
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { hover = true; startAnimation(); }
            @Override public void mouseExited(MouseEvent e) { hover = false; pressed = false; startAnimation(); }
            @Override public void mousePressed(MouseEvent e) { pressed = true; startAnimation(); }
            @Override public void mouseReleased(MouseEvent e) { pressed = false; startAnimation(); }
        });
    }

    private void startAnimation() {
        if (!animationTimer.isRunning()) animationTimer.start();
    }

    @Override
    public void removeNotify() {
        animationTimer.stop();
        super.removeNotify();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();
        float scale = 1f + hoverProgress * 0.035f - pressProgress * 0.045f;
        int arc = 20 + Math.round(hoverProgress * 8);

        g2.translate(w / 2.0, h / 2.0);
        g2.scale(scale, scale);
        g2.translate(-w / 2.0, -h / 2.0);

        Color c1 = danger ? UITheme.WARNING : UITheme.PRIMARY;
        Color c2 = danger ? new Color(170, 40, 55) : UITheme.PRIMARY_DARK;
        c1 = blend(c1, Color.WHITE, hoverProgress * 0.18f);
        c2 = blend(c2, UITheme.ACCENT, hoverProgress * 0.16f);

        int glowAlpha = 35 + Math.round(hoverProgress * 80);
        g2.setColor(new Color(c1.getRed(), c1.getGreen(), c1.getBlue(), glowAlpha));
        g2.fillRoundRect(3, 3, w - 6, h - 4, arc + 8, arc + 8);

        g2.setColor(new Color(0, 0, 0, 115));
        g2.fillRoundRect(6, 8, w - 12, h - 10, arc, arc);

        g2.setPaint(new GradientPaint(0, 0, c1, w, h, c2));
        g2.fillRoundRect(0, 0, w - 5, h - 7, arc, arc);

        int shineAlpha = 45 + Math.round(hoverProgress * 65);
        g2.setPaint(new GradientPaint(0, 0, new Color(255, 255, 255, shineAlpha), 0, h / 2f, new Color(255, 255, 255, 0)));
        g2.fillRoundRect(2, 2, w - 9, Math.max(12, h / 2), arc, arc);

        g2.setColor(new Color(255, 255, 255, 60 + Math.round(hoverProgress * 90)));
        g2.drawRoundRect(0, 0, w - 6, h - 8, arc, arc);

        String label = getText();
        FontMetrics fm = g2.getFontMetrics(getFont());
        int textX = (w - fm.stringWidth(label)) / 2;
        int textY = (h - fm.getHeight()) / 2 + fm.getAscent() - 3;
        g2.setFont(getFont().deriveFont(Font.BOLD, getFont().getSize2D() + hoverProgress));
        fm = g2.getFontMetrics();
        textX = (w - fm.stringWidth(label)) / 2;
        textY = (h - fm.getHeight()) / 2 + fm.getAscent() - 3;
        g2.setColor(new Color(0, 0, 0, 80));
        g2.drawString(label, textX + 1, textY + 2);
        g2.setColor(Color.WHITE);
        g2.drawString(label, textX, textY);
        g2.dispose();
    }

    private Color blend(Color a, Color b, float ratio) {
        ratio = Math.max(0f, Math.min(1f, ratio));
        int r = (int) (a.getRed() * (1 - ratio) + b.getRed() * ratio);
        int g = (int) (a.getGreen() * (1 - ratio) + b.getGreen() * ratio);
        int bl = (int) (a.getBlue() * (1 - ratio) + b.getBlue() * ratio);
        return new Color(r, g, bl);
    }
}

class AnimatedSnakePanel extends JPanel {
    private int tick = 0;
    private final javax.swing.Timer timer;

    public AnimatedSnakePanel() {
        setOpaque(false);
        timer = new javax.swing.Timer(80, e -> {
            tick++;
            repaint();
        });
        timer.start();
    }

    @Override
    public void removeNotify() {
        timer.stop();
        super.removeNotify();
    }

    @Override
    public void addNotify() {
        super.addNotify();
        if (!timer.isRunning()) timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        UITheme.paintGradientBackground(g2, w, h);

        g2.setColor(new Color(255, 255, 255, 10));
        int grid = 34;
        for (int x = 0; x <= w; x += grid) g2.drawLine(x, 0, x, h);
        for (int y = 0; y <= h; y += grid) g2.drawLine(0, y, w, y);

        drawSnake(g2, w, h, 0, h / 2 + 10, 14, 26, 0.22, 0);
        drawSnake(g2, w, h, w / 4, h / 3, 10, 22, 0.3, 120);
        drawFood(g2, (int)(w * 0.76), (int)(h * 0.27), 26);
        drawFood(g2, (int)(w * 0.22), (int)(h * 0.72), 20);

        g2.setColor(new Color(255, 255, 255, 18));
        for (int i = 0; i < 16; i++) {
            int px = (i * 97 + tick * 9) % Math.max(1, w);
            int py = (i * 53 + tick * 5) % Math.max(1, h);
            g2.fillOval(px, py, 3, 3);
        }

        g2.dispose();
    }

    private void drawSnake(Graphics2D g2, int w, int h, int offsetX, int baseY, int segments, int size, double waveSpeed, int phase) {
        int gap = Math.max(18, size - 2);
        int travel = Math.max(1, w + segments * gap + 200);
        int headX = (offsetX + tick * 7 + phase) % travel - 140;

        for (int i = segments - 1; i >= 0; i--) {
            int x = headX - i * gap;
            double wave = Math.sin((tick + phase + i * 3) * waveSpeed);
            int y = baseY + (int) (wave * 34);
            if (x < -size || x > w + size) continue;

            float ratio = i / (float) Math.max(1, segments - 1);
            Color body = blend(UITheme.PRIMARY_DARK, UITheme.PRIMARY, 0.35f + ratio * 0.65f);
            g2.setColor(new Color(0, 0, 0, 75));
            g2.fillRoundRect(x + 4, y + 5, size, size, 16, 16);
            g2.setPaint(new GradientPaint(x, y, body.brighter(), x + size, y + size, body.darker()));
            g2.fillRoundRect(x, y, size, size, 16, 16);
            g2.setColor(new Color(255, 255, 255, 40));
            g2.drawRoundRect(x, y, size, size, 16, 16);
        }

        int y = baseY + (int) (Math.sin((tick + phase) * waveSpeed) * 34);
        if (headX > -size && headX < w + size) {
            g2.setColor(Color.WHITE);
            g2.fillOval(headX + size / 2, y + 6, 5, 5);
            g2.fillOval(headX + size / 2, y + size - 11, 5, 5);
            g2.setColor(new Color(10, 20, 18));
            g2.fillOval(headX + size / 2 + 2, y + 8, 2, 2);
            g2.fillOval(headX + size / 2 + 2, y + size - 9, 2, 2);
            int tongueLen = 8 + (tick % 3);
            g2.setColor(new Color(255, 95, 120, 180));
            g2.drawLine(headX + size - 2, y + size / 2, headX + size - 2 + tongueLen, y + size / 2 - 2);
            g2.drawLine(headX + size - 2, y + size / 2, headX + size - 2 + tongueLen, y + size / 2 + 2);
        }
    }

    private void drawFood(Graphics2D g2, int x, int y, int size) {
        int pulse = 4 + (int) (Math.sin(tick * 0.32) * 3);
        g2.setColor(new Color(255, 90, 120, 50));
        g2.fillOval(x - pulse, y - pulse, size + pulse * 2, size + pulse * 2);
        g2.setPaint(new GradientPaint(x, y, new Color(255, 110, 130), x + size, y + size, new Color(255, 205, 78)));
        g2.fillOval(x, y, size, size);
        g2.setColor(new Color(255, 255, 255, 110));
        g2.fillOval(x + size / 4, y + size / 5, Math.max(4, size / 4), Math.max(4, size / 4));
    }

    private Color blend(Color a, Color b, float ratio) {
        ratio = Math.max(0f, Math.min(1f, ratio));
        int r = (int) (a.getRed() * (1 - ratio) + b.getRed() * ratio);
        int g = (int) (a.getGreen() * (1 - ratio) + b.getGreen() * ratio);
        int bl = (int) (a.getBlue() * (1 - ratio) + b.getBlue() * ratio);
        return new Color(r, g, bl);
    }
}
