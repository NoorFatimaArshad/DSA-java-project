/**
 * SnakeNode represents one segment of the snake body.
 * Every node stores x and y grid coordinates.
 */
public class SnakeNode {
    int x;
    int y;
    SnakeNode next;

    public SnakeNode(int x, int y) {
        this.x = x;
        this.y = y;
        this.next = null;
    }
}
