import javax.swing.*;
import java.awt.*;

/**
 * Main class starts the Snake Game application.
 */
public class Main {
    public static final int WIDTH = 900;
    public static final int HEIGHT = 700;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Advanced DSA Snake Game - Modern GUI");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(WIDTH, HEIGHT);
            frame.setResizable(false);
            frame.setLocationRelativeTo(null);
            frame.setLayout(new CardLayout());

            ScoreManager scoreManager = new ScoreManager("scores.txt");
            PlayerHistoryManager historyManager = new PlayerHistoryManager("history.txt");

            MainMenu mainMenu = new MainMenu(frame, scoreManager, historyManager);
            frame.add(mainMenu, "MENU");

            frame.setVisible(true);
        });
    }
}
